const Meta = imports.gi.Meta;
const GLib = imports.gi.GLib;

const change_workspace = (win, manager, index) => {
  const n = manager.get_n_workspaces();
  if (n <= index) {
    return;
  }
  win.change_workspace_by_index(index, 1);
  manager.get_workspace_by_index(index).activate(global.get_current_time());
};

const _old_workspaces = {};
const _full_screen_apps = {};

const first_empty_workspace_index = (manager, win) => {
  const n = manager.get_n_workspaces();
  let lastworkspace = n - 1;
  for (let i = 0; i < lastworkspace; ++i) {
    let win_count = manager.get_workspace_by_index(i)
      .list_windows()
      .filter(w => !w.is_always_on_all_workspaces() && win.get_monitor() == w.get_monitor()).length;
    if (win_count < 1) {
      return i;
    }
  }
  if (lastworkspace < 1) lastworkspace = 1
  return lastworkspace;
}

function check(win, change) {
  const workspacemanager = win.get_display().get_workspace_manager();
  if (win.window_type !== Meta.WindowType.NORMAL) {
    return;
  }
  const name = win.get_id();
  const w = win.get_workspace().list_windows()
    .filter(w => w !== win && !w.is_always_on_all_workspaces() && win.get_monitor() == w.get_monitor());
  if (change === Meta.SizeChange.UNFULLSCREEN || change === Meta.SizeChange.UNMAXIMIZE || (change === Meta.SizeChange.MAXIMIZE && win.get_maximized() !== Meta.MaximizeFlags.BOTH)) {
    if (_full_screen_apps[name] !== undefined) {
      if (w.length == 0) {
        change_workspace(win, workspacemanager, _full_screen_apps[name]);
      }
      _full_screen_apps[name] = undefined;
      return;
    }
    if (_old_workspaces[name] !== undefined) {
      if (w.length == 0) {
        change_workspace(win, workspacemanager, _old_workspaces[name]);
      }
      _old_workspaces[name] = undefined;
    }
    return;
  }

  if (change === Meta.SizeChange.FULLSCREEN) {
    _full_screen_apps[name] = win.get_workspace().index();
  } else {
    _old_workspaces[name] = win.get_workspace().index();
  }
  if (w.length >= 1) {
    let emptyworkspace = first_empty_workspace_index(workspacemanager, win);
    if (emptyworkspace == win.get_workspace().index()) {
      return;
    }
    change_workspace(win, workspacemanager, emptyworkspace);
  }
}

function handleWindowClose(act) {
  let win = act.meta_window;
  let name = win.get_id();
  if (_old_workspaces[name] !== undefined) {
    win.get_display().get_workspace_manager().get_workspace_by_index(_old_workspaces[name]).activate(global.get_current_time());
  }
};

const _window_manager_handles = [];

function enable() {
  _window_manager_handles.push(global.window_manager.connect('map', (_, act, change) => {
    if (act.meta_window.get_maximized() === Meta.MaximizeFlags.BOTH) {
      check(act.meta_window, change);
    }
  }));
  _window_manager_handles.push(global.window_manager.connect('size-change', (_, act, change) => {
    check(act.meta_window, change);
  }));
  _window_manager_handles.push(global.window_manager.connect('destroy', (_, act) => {
    handleWindowClose(act);
  }));
}

function disable() {
  _window_manager_handles.splice(0).forEach(h => global.window_manager.disconnect(h));
}