* All icons/img are custom made.

* All translators are credited in the po files as well as the commit mesages.

* Sound files are *royalty free* or *public domain* and come from:
    * http://www.bigsoundbank.com/
    * http://soundbible.com/royalty-free-sounds-1.html
